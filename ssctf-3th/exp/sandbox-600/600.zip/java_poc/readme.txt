题目类型：Java 漏洞分析与利用

提交说明:
1.EXP及源代码(突破Java Applet沙箱，弹出计算器)。
2.漏洞分析文档。
3.成功突破沙箱，弹出计算器的GIF。

题目说明：

1. src文件夹内包含漏洞的poc源代码
2. jdk文件夹内包含影响的一个java版本
3. bin文件夹内包含漏洞的jar版本

测试环境：

Windows 7 SP1 x86 + jdk_1.8.0_77

验证poc：

第一步：安装jdk,添加jdk安装的bin目录路径到系统环境变量（path）中
第二步：给appletviewer.exe工具开启页堆和栈追踪数据库（gflags.exe -I appletviewer.exe +hpa +ust）
第三步：运行poc（appletviewer poc.html），这时会发现程序已崩溃，并会产生一个崩溃日志文件（类似hs_err_pid*.log）

