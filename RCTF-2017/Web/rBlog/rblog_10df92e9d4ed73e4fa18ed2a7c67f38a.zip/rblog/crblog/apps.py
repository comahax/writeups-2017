from django.apps import AppConfig


class CrblogConfig(AppConfig):
    name = 'crblog'
