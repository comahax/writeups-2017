from django.conf.urls import url

from . import views

urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^archive$', views.archive, name='archive'),
	url(r'^archive/(?P<pyear>\d{4})$', views.archive, name='archive_year'),
	url(r'^post/(?P<ptitle>.+)$', views.posts, name='posts'),
	url(r'^link$', views.link, name='link'),
	url(r'^feed$', views.feed, name='feed')
]