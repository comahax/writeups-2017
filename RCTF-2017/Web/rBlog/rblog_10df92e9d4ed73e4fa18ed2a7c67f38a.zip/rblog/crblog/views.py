from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Post, FriendLink
from codecs import open


def index(request):
	return render(request, 'index.html', {
		'nbar': 'index',
		'posts': Post.objects.order_by('-date').values('id', 'title', 'date')[:2]
	})


def archive(request, pyear=0):
	if pyear:
		posts = Post.objects.filter(date__year=pyear).order_by('-date').values('id', 'title', 'date')
	else:
		posts = Post.objects.order_by('-date').values('id', 'title', 'date')
	return render(request, 'archive.html', {
		'nbar': 'archive',
		'posts': posts
	})


def posts(request, ptitle):
	p = get_object_or_404(Post, title=ptitle)
	return render(request, 'post.html', {'post': p})


def link(request):
	return render(request, 'link.html', {
		'nbar': 'link',
		'friends': FriendLink.objects.all().order_by('?')
	})


def feed(request):
	with open('crblog/static/atom.xml', 'r', 'utf-8') as f:
		xml = f.read()
	return HttpResponse(xml, content_type="application/xml")
