from django.contrib import admin

# Register your models here.
from .models import Post, PostAdmin, FriendLink, FriendLinkAdmin

admin.site.register(Post, PostAdmin)
admin.site.register(FriendLink, FriendLinkAdmin)