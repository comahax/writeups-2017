from django.db import models
from django.contrib import admin
from django.dispatch import receiver

from markdown import markdown
from codecs import open
from os import remove
from django.utils import feedgenerator


class Post(models.Model):
	title = models.CharField(max_length=200)
	date = models.DateField()
	context = models.TextField()

	def __str__(self):
		return self.title


@receiver(models.signals.post_save, sender=Post)
def generatehtml(sender, instance, **kwargs):
	with open('crblog/templates/posts/%d.html' % instance.id, 'w', 'utf-8') as f:
		f.write(markdown(instance.context, extensions=['markdown.extensions.fenced_code']))
	generatefeed()


@receiver(models.signals.post_delete, sender=Post)
def removehtml(sender, instance, **kwargs):
	remove('crblog/templates/posts/%d.html' % instance.id)
	generatefeed()


class PostAdmin(admin.ModelAdmin):
	list_display = ('id', 'title', 'date')
	ordering = ['-date']
	actions = ['regenerateatom', 'regenerateall']

	def regenerateatom(modeladmin, request, queryset):
		generatefeed()

	regenerateatom.short_description = "Regenerate atom.xml"

	def regenerateall(modeladmin, request, queryset):
		for i in Post.objects.all():
			with open('crblog/templates/posts/%d.html' % i.id, 'w', 'utf-8') as f:
				f.write(markdown(i.context, extensions=['markdown.extensions.fenced_code']))
		generatefeed()

	regenerateall.short_description = "Regenerate all HTMLs and atom.xml"


class FriendLink(models.Model):
	name = models.CharField(max_length=100)
	url = models.CharField(max_length=100)
	description = models.CharField(max_length=400)

	def __str__(self):
		return self.name


class FriendLinkAdmin(admin.ModelAdmin):
	list_display = ('name', 'url', 'description')


def generatefeed():
	print("generatefeed called")
	f = feedgenerator.Atom1Feed(
		title="rblog1.0",
		link="http://rblog.2017.teamrois.cn",
		description="rblog1.0"
	)
	for i in Post.objects.order_by('-date').values('id', 'title', 'date')[:3]:
		with open('crblog/templates/posts/%d.html' % i['id'], 'r', 'utf-8') as fpost:
			context = fpost.read()
		f.add_item(
			title=i['title'],
			link='http://rblog.2017.teamrois.cn/post/' + i['title'],
			description=context,
			pubdate=i['date'],
			unique_id=str(i['id']),
		)
	with open('crblog/static/atom.xml', 'w', 'utf-8') as fatom:
		f.write(fatom, 'utf-8')
