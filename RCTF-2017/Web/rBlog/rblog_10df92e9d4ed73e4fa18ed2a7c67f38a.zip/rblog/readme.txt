Step1: Generate a SECRET_KEY and add it to rblog/blog/settings.py
	for python < 3.6:
		import random, string
		print(''.join([random.choice(string.ascii_letters+string.digits) for _ in 	range(50)]))
	for python >= 3.6:
		import random, string
		print(''.join(random.choices(string.ascii_letters+string.digits, k=50)))

Step2: Init database and create an admin account
	python3 manage.py makemigrations
	python3 manage.py migrate
	python3 manage.py createsuperuser

Step3: Run server
	python3 manage.py runserver ip:port (e.g. 0.0.0.0:80)

Remember to set DEBUG=False in rblog/blog/settings.py and read https://docs.djangoproject.com/en/1.11/howto/deployment/ when deploying!