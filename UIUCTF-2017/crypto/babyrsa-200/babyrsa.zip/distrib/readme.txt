Message intercepted. Break it.
